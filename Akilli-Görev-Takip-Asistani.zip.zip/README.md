
#  Python - Akıllı Görev Takip Asistanı

Python ile geliştirilen bu proje, kullanıcıların görevlerini takip etmelerini kolaylaştıran terminal tabanlı bir görev asistanıdır.

##  Özellikler
- Görev ekleme, listeleme ve silme
- Tarihli görev hatırlatmaları
- JSON dosyasına veri kaydı
- Modüler Python mimarisi

##  Kurulum
```bash
git clone https://github.com/kullanıcı_adı/python_akıllı_görev_takip_asistanı.git
cd python_akıllı_görev_takip_asistanı
python -m venv venv
venv\Scripts\activate
python main.py