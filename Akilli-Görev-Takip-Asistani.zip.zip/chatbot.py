
from task_manager import TaskManager
from reminder_module import Reminder
from storage import Storage

class ChatBot:
    def __init__(self):
        self.task_manager = TaskManager()
        self.reminder = Reminder(self.task_manager)

    def start(self):
        print("🎯 Python Akıllı Görev Takip Asistanın'a Hoş Geldiniz!")
        while True:
            self.reminder.check_due_tasks()
            command = input("\nKomut girin (ekle/listele/sil/sıfırla/çık): ").strip().lower()

            if command == "ekle":
                title = input("Görev başlığı: ")
                date = input("Tarih (opsiyonel - yyyy-aa-gg): ")
                self.task_manager.add_task(title, date)

            elif command == "listele":
                self.task_manager.list_tasks()

            elif command == "sil":
                try:
                    task_id = int(input("Silmek istediğiniz görev ID'si: "))
                    self.task_manager.delete_task(task_id)
                except ValueError:
                    print("❌ Lütfen geçerli bir sayı girin.")

            elif command == "sıfırla":
                confirm = input("Tüm görevleri silmek istediğinize emin misiniz? (evet/hayır): ").strip().lower()
                if confirm == "evet":
                    self.task_manager.tasks = []
                    Storage.save_tasks([])
                    print("📭 Tüm görevler silindi.")
                else:
                    print("❌ İşlem iptal edildi.")

            elif command == "çık":
                print("👋 Görüşmek üzere!")
                break

            else:
                print("❗ Tanımsız komut girdiniz.")
