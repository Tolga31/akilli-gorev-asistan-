from chatbot import  ChatBot

if __name__ == "__main__":
    bot = ChatBot()
    bot.start()

    # Bu dosya çalıştırıldığında chatbot başlatılacak.